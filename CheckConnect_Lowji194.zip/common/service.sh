#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

#!/system/bin/sh
        device_name=$(settings get global device_name)
while true; do
dumpsys battery set level 999
    sleep 3600
    # Kiểm tra kết nối mạng bằng lệnh ping và lưu kết quả vào tệp tin
    ping -c 1 google.com > /data/local/tmp/ping_output.txt 2>&1

    # Kiểm tra xem lệnh ping đã thành công hay không
    if [ $? -eq 0 ]; then
        echo "Kết nối mạng hoạt động."
    else
        echo "Không có kết nối mạng."

		setprop ro.bootmode "normal"
		setprop sys.powerctl "reboot"
    fi
done
